package com.gdg.bhopal.mycollegeapp;

public class InfoObject {
    String name, gender, date, email, phone, course, college, username, password;

    public InfoObject(String name, String gender, String date, String email, String phone, String college, String course, String username, String password) {
        this.name = name;
        this.gender = gender;
        this.date = date;
        this.email = email;
        this.phone = phone;
        this.college = college;
        this.course = course;
        this.username = username;
        this.password = password;
    }

    public String getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getCourse() {
        return course;
    }

    public String getCollege() {
        return college;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

}
