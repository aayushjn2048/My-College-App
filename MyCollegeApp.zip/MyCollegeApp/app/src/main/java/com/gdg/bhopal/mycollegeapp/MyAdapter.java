package com.gdg.bhopal.mycollegeapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    ArrayList<InfoObject> infoList;
    Context context;

    public MyAdapter(ArrayList<InfoObject> infoList, Context context) {
        this.infoList = infoList;
        this.context = context;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name, email, phone;

        public MyViewHolder(@NonNull View itemView)
        {
            super(itemView);
            name = (TextView)itemView.findViewById(R.id.textname);
            email = (TextView)itemView.findViewById(R.id.textemail);
            phone = (TextView)itemView.findViewById(R.id.textphone);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView  = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        InfoObject io = infoList.get(position);
        holder.name.setText(io.getName());
        holder.email.setText(io.getEmail());
        holder.phone.setText(io.getPhone());
    }

    @Override
    public int getItemCount() {
        return infoList.size();
    }
}
