package com.gdg.bhopal.mycollegeapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ChooseActivity extends AppCompatActivity implements View.OnClickListener{
    CardView cardProfile, cardList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        cardProfile = (CardView)findViewById(R.id.cardProfile);
        cardList = (CardView)findViewById(R.id.cardList);

        cardProfile.setOnClickListener(this);
        cardList.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        if(v == cardProfile) {
            startActivity(new Intent(this, ShowProfile.class));
        }
        if(v == cardList) {
            startActivity(new Intent(this, ViewList.class));
        }
    }
}
