package com.gdg.bhopal.mycollegeapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class ViewList extends AppCompatActivity {

    MyAdapter myAdapter;
    RecyclerView recyclerView;
    ArrayList<InfoObject> mylist;
    DbHelper dbhelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list);

        mylist = new ArrayList<InfoObject>();
        try {
            ProgressDialog progressDialog;
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Please Wait...");
            progressDialog.show();
            dbhelper = new DbHelper(this);
            mylist = dbhelper.getInfo();

            myAdapter = new MyAdapter(mylist, this);

            recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
            recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            recyclerView.setAdapter(myAdapter);
            myAdapter.notifyDataSetChanged();
            progressDialog.dismiss();
        }
        catch(Exception ex)
        {
            Log.e("ViewError: ",ex.toString());
        }

    }
}
