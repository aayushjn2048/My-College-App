package com.gdg.bhopal.mycollegeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ShowProfile extends AppCompatActivity {
    SharedPreferences mypref;
    TextView textname, textgender, textdate, textemail, textphone, textcollege, textcourse;
    Button logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_profile);

        textname = (TextView)findViewById(R.id.editname);
        textgender = (TextView)findViewById(R.id.editgender);
        textdate = (TextView)findViewById(R.id.editdate);
        textemail = (TextView)findViewById(R.id.editemail);
        textphone = (TextView)findViewById(R.id.editphone);
        textcollege = (TextView)findViewById(R.id.editcollege);
        textcourse = (TextView)findViewById(R.id.editcourse);
        logoutButton = (Button)findViewById(R.id.logoutbutton);

        mypref = getSharedPreferences("MYPREF", MODE_PRIVATE);

        String name =mypref.getString("name",null);
        String gender =mypref.getString("gender",null);
        String date =mypref.getString("date",null);
        String email =mypref.getString("email",null);
        String phone =mypref.getString("phone",null);
        String college =mypref.getString("college",null);
        String course =mypref.getString("course",null);

        textname.setText(name);
        textgender.setText(gender);
        textdate.setText(date);
        textemail.setText(email);
        textphone.setText(phone);
        textcollege.setText(college);
        textcourse.setText(course);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ShowProfile.this, MainActivity.class));
                finish();
            }
        });

    }
}
