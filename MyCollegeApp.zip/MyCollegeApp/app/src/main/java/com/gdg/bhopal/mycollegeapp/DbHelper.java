package com.gdg.bhopal.mycollegeapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.icu.text.IDNA;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.EmptyStackException;

public class DbHelper extends SQLiteOpenHelper {
    static String DB_Name = "studentinfo.db";
    static int DB_Version = 1;

    public static String Table_Name = "studentinfo";
    public static String ID_COL = "id";
    public static String NAME_COL = "name";
    public static String EMAIL_COL = "email";
    public static String PHONE_COL = "phone";
    public static String GENDER_COL = "gender";
    public static String DATE_COL = "birthday";
    public static String USERNAME_COL = "username";
    public static String PASSWORD_COL = "password";
    public static String COURSE_COL = "course";
    public static String COLLEGE_COL = "college";

    public static String query = "create table "+Table_Name+"( "+
            ID_COL+" integer primary key autoincrement, "+
            NAME_COL+" varchar, "+
            GENDER_COL + " varchar, "+
            DATE_COL + " varchar, "+
            EMAIL_COL + " varchar, "+
            PHONE_COL + " varchar, "+
            COLLEGE_COL + " varchar, "+
            COURSE_COL + " varchar, "+
            USERNAME_COL + " varchar, "+
            PASSWORD_COL + " varchar)";

    public DbHelper(@Nullable Context context) {
        super(context, DB_Name, null, DB_Version);
    }

    public boolean userExist(String email, String phone)
    {
        String[] columns = { ID_COL };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = EMAIL_COL + "=? " + PHONE_COL + "=? ";
        String[] selectionArgs = { email, phone};
        Cursor cursor = db.query(Table_Name, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if(count>0)
            return true;
        else
            return false;
    }

    public boolean insertInfo(InfoObject io){
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(NAME_COL, io.getName());
            cv.put(GENDER_COL, io.getGender());
            cv.put(DATE_COL, io.getDate());
            cv.put(EMAIL_COL, io.getEmail());
            cv.put(PHONE_COL, io.getPhone());
            cv.put(COLLEGE_COL, io.getCollege());
            cv.put(COURSE_COL, io.getCourse());
            cv.put(USERNAME_COL, io.getUsername());
            cv.put(PASSWORD_COL, io.getPassword());
            db.insert(Table_Name, null, cv);
        }catch (Exception ex){
            Log.e("Apun ka error: ",ex.toString());
            return false;
        }
        return true;
    }

    public boolean checkUser(String username, String password)
    {
        String[] columns = { ID_COL };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = USERNAME_COL + "=? " + " and " + PASSWORD_COL + "=? ";
        String[] selectionArgs = { username, password };
        Cursor cursor = db.query(Table_Name, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if(count>0)
            return true;
        else
            return false;
    }

    public InfoObject myInfo(String username, String password)
    {
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] columns = {NAME_COL, GENDER_COL, DATE_COL, EMAIL_COL, PHONE_COL, COLLEGE_COL, COURSE_COL};
            String selection = USERNAME_COL + "=?" + " and " + PASSWORD_COL + "=? ";
            String[] selectionArgs = {username, password};
            Cursor cursor = db.query(Table_Name, columns, selection, selectionArgs, null, null, null);
            cursor.moveToFirst();
            String name = cursor.getString(0);
            String gender = cursor.getString(1);
            String date = cursor.getString(2);
            String email = cursor.getString(3);
            String phone = cursor.getString(4);
            String college = cursor.getString(5);
            String course = cursor.getString(6);
            InfoObject myobject = new InfoObject(name, gender, date, email, phone, college, course, null, null);
            cursor.close();
            db.close();
            return myobject;
        }
        catch(Exception ex)
        {
            Log.e("DBError:",ex.toString());
        }
        return null;
    }


    public ArrayList<InfoObject> getInfo(){
        ArrayList<InfoObject> myinfo = new ArrayList<InfoObject>();
        try{
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor c = db.rawQuery("SELECT * FROM " + Table_Name,null);
            c.moveToFirst();
            do{
                String name = c.getString(c.getColumnIndex(NAME_COL));
                String gender = c.getString(c.getColumnIndex(GENDER_COL));
                String date = c.getString(c.getColumnIndex(DATE_COL));
                String email = c.getString(c.getColumnIndex(EMAIL_COL));
                String phone = c.getString(c.getColumnIndex(PHONE_COL));
                String college = c.getString(c.getColumnIndex(COLLEGE_COL));
                String course = c.getString(c.getColumnIndex(COURSE_COL));
                String username = c.getString(c.getColumnIndex(USERNAME_COL));
                String password = c.getString(c.getColumnIndex(PASSWORD_COL));
                InfoObject io = new InfoObject(name, gender, date, email, phone, college, course, username, password);
                myinfo.add(io);
            }while(c.moveToNext());
            c.close();
            db.close();
        }catch(Exception ex){
            Log.e("ERROR",ex.toString());
        }
        return myinfo;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
