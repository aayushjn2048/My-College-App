package com.gdg.bhopal.mycollegeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button loginButton;
    EditText username,password;
    TextView signUp;
    DbHelper dbhelper;
    SharedPreferences mypref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbhelper = new DbHelper(this);
        mypref = getSharedPreferences("MYPREF", MODE_PRIVATE);
        username = (EditText)findViewById(R.id.editText);
        password = (EditText)findViewById(R.id.editText2);
        loginButton = (Button) findViewById(R.id.loginButton);
        signUp = (TextView)findViewById(R.id.textSignUp);
        loginButton.setOnClickListener(this);
        signUp.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v == loginButton){
            String myUserName = username.getText().toString();
            String myPassword = password.getText().toString();
            if(dbhelper.checkUser(myUserName,myPassword))
            {
                try
                {
                    ProgressDialog progressDialog = new ProgressDialog(this);
                    progressDialog.setMessage("Please Wait...");
                    progressDialog.show();
                    SharedPreferences.Editor editor = mypref.edit();
                    InfoObject myobject = dbhelper.myInfo(myUserName, myPassword);
                    Toast.makeText(this, "Check name: "+myobject.getName(), Toast.LENGTH_SHORT).show();
                    editor.putString("name", myobject.getName());
                    editor.putString("gender", myobject.getGender());
                    editor.putString("date", myobject.getDate());
                    editor.putString("email", myobject.getEmail());
                    editor.putString("phone", myobject.getPhone());
                    editor.putString("college", myobject.getCollege());
                    editor.putString("course", myobject.getCourse());
                    editor.putString("username", null);
                    editor.putString("password", null);
                    editor.apply();
                    progressDialog.dismiss();
                    startActivity(new Intent(this, ChooseActivity.class));
                }
                catch (Exception ex)
                {
                    Log.e("MyError: ",ex.toString());
                }
            }
            else
                Toast.makeText(this,"Wrong Username or Password",Toast.LENGTH_SHORT).show();
        }
        else if(v == signUp)
        {
            startActivity(new Intent(this,RegisterPage.class));
        }
    }
}
