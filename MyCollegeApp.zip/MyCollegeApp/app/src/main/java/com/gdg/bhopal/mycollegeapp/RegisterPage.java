package com.gdg.bhopal.mycollegeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class RegisterPage extends AppCompatActivity {
    Button RegisterButton;
    EditText editName, editDate, editEmail, editPhone, editCollege, editusername, editPassword;
    Spinner myCourse;
    RadioGroup chooseGender;
    RadioButton myGender;
    SharedPreferences mypref = null;
    DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        dbHelper=new DbHelper(this);
        mypref = getSharedPreferences("MYPREF", MODE_PRIVATE);
        editName = (EditText)findViewById(R.id.editname);
        editDate = (EditText)findViewById(R.id.editDate);
        editEmail = (EditText)findViewById(R.id.editEmail);
        editPhone = (EditText)findViewById(R.id.editPhone);
        editCollege = (EditText)findViewById(R.id.editCollege);
        myCourse = (Spinner)findViewById(R.id.spinner);
        editusername = (EditText)findViewById(R.id.editUsername);
        editPassword = (EditText)findViewById(R.id.editPassword);
        chooseGender = (RadioGroup)findViewById(R.id.genderGroup);
        RegisterButton = (Button)findViewById(R.id.registerButton);
        RegisterButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //Toast.makeText(RegisterPage.this,"Main hoon na!!!", Toast.LENGTH_LONG).show();
                String name = editName.getText().toString();
                String date = editDate.getText().toString();
                String email = editEmail.getText().toString();
                String phone = editPhone.getText().toString();
                String college = editCollege.getText().toString();
                String username = editusername.getText().toString();
                String password = editPassword.getText().toString();
                int selectedId = chooseGender.getCheckedRadioButtonId();
                myGender = (RadioButton) findViewById(selectedId);
                String gender = myGender.getText().toString();
                String course = myCourse.getSelectedItem().toString();
                //Toast.makeText(RegisterPage.this, "Details: "+name+" "+gender+" "+date+" "+email+" "+phone+" "+college+" "+course+" "+username+" "+password, Toast.LENGTH_SHORT).show();
                    try {
                        InfoObject myInfo = new InfoObject(name, gender, date, email, phone, college, course, username, password);

                        SharedPreferences.Editor editor = mypref.edit();
                        editor.putString("name", name);
                        editor.putString("gender", gender);
                        editor.putString("date", date);
                        editor.putString("email", email);
                        editor.putString("phone", phone);
                        editor.putString("college", college);
                        editor.putString("course", course);
                        editor.putString("username", username);
                        editor.putString("password", password);
                        editor.apply();

                        Boolean val = dbHelper.insertInfo(myInfo);
                        if (val == true) {
                            Toast.makeText(RegisterPage.this, "User Registered Successfully!!!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterPage.this, ChooseActivity.class));
                        } else {
                            Toast.makeText(RegisterPage.this, "Error found while registering user!!!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception ex) {
                        Log.e("Mera error: ", ex.toString());
                    }

                }
        });
    }
}
